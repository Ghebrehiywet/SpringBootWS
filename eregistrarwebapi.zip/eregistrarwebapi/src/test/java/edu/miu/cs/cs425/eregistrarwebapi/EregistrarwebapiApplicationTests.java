package edu.miu.cs.cs425.eregistrarwebapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EregistrarwebapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
