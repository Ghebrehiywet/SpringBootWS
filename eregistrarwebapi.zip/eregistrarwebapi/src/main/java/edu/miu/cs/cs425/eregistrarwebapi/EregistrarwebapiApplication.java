package edu.miu.cs.cs425.eregistrarwebapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EregistrarwebapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(EregistrarwebapiApplication.class, args);
    }

}
