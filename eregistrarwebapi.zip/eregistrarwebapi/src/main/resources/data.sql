insert into student (student_number,first_name , middle_name,last_name,cgpa, enrollment_date, is_international)
			values ("000-61-0001","Anna","","Smith","3.78",date("2019-5-12"),1);

insert into student (student_number,first_name , middle_name,last_name,cgpa, enrollment_date, is_international)
			values ("000-61-0011","Mike","","Jhon","3.99",date("2018-6-12"),0);

insert into student (student_number,first_name , middle_name,last_name,cgpa, enrollment_date, is_international)
			values ("000-61-0111","Joe","","Bob","3.25",date("2017-11-12"),1);

insert into student (student_number,first_name , middle_name,last_name,cgpa, enrollment_date, is_international)
			values ("000-61-1111","Alice","","Cesaer","4.00",date("2020-10-03"),1);